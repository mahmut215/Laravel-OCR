**Anyone is always welcome to contribute on the project. If you want to work with:**
1. Just create and issue(even if you want to fix the issue). 
2. After fixing any issue or adding any new feature just send a pull request
3. I will be happy to add your code for the betterment of this project. 
Thanks.
